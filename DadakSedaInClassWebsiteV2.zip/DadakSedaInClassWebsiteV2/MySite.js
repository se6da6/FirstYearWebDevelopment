function jumpToTop()
{
    window.scrollTo(0,0);  
}

function jumpToBottom()
{
    window.scrollTo(0,document.body.scrollHeight);
}
function todaysDate()
{
    var rightNow2 =  new Date();
	var theMonth = 0, todaysDate = "";  
	theMonth = rightNow2.getMonth() + 1;
	todaysDate = theMonth + '-' + rightNow2.getDate() 
                + '-' + rightNow2.getFullYear();
	document.getElementById("showDate").innerHTML = todaysDate;
}
function changeTable()
{
    document.getElementById("demo").style.borderWidth = "0.5 em";
    document.getElementById("demo").style.borderStyle = "dashed";
    document.getElementById("demo").style.borderColor = "orange";
    document.getElementById("demo").style.color = "blue";

}